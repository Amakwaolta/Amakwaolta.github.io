## ブログ記事

- 何故Hugo?
- 仮想DOMはいらない
- Vite、何がよくて何がだめか。そしてRolldown
- コマンド紹介シリーズ
- Cloudflare Pages vs GitHub Pages
- yamlを評価
- 分散SNSってよく言えば温故知新、悪く言えば車輪の再発明。
- ACメソッド 因数分解
- ED法
  https://qiita.com/kanekanekaneko/items/901ee2837401750dfdad

## 構造

sitemap.xml などのためにサブプロジェクトにルートを作って別リポのpagesで上書き
- yt-stream
- altproject
