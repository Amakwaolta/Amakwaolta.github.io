---
title: AltProject
summary: Alternative frontends, self-hosting, etc.
date: 2024-04-06
---
