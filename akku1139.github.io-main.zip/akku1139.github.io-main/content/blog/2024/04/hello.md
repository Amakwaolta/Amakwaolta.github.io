---
title: こんにちは
summary: 初回
date: 2024-04-04
---

こんにちは!

前はAstroを使用していましたが今回はHugoで作ってみました。
